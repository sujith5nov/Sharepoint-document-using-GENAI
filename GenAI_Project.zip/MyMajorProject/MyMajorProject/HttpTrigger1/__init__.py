import logging
import json
import os
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents.models import VectorizedQuery
from azure.search.documents.models import VectorFilterMode
import azure.functions as func
from openai import AzureOpenAI
from azure.functions import HttpResponse

embedding_client = AzureOpenAI(
    azure_endpoint="https://openai-azuretesting.openai.azure.com/",
    api_key="d57bdf8c8fd54d98aea4f20e0a183479",
    api_version="2024-02-15-preview"
)

def generate_embedding(embedding_client, text):
    emb = embedding_client.embeddings.create(model="text-embedding-3-small", input=text)
    res = json.loads(emb.model_dump_json())
    return res["data"][0]["embedding"]
# Function to query documents from the SharePoint index
def query_documents(query, department=None):
    search_endpoint = os.getenv('SEARCH_ENDPOINT')
    search_key = os.getenv('SEARCH_API_KEY')
    index_name = os.getenv('INDEX_NAME')

    search_client = SearchClient(endpoint=search_endpoint, 
                                 index_name=index_name, 
                                 credential=AzureKeyCredential(search_key))
    
    embed_query=generate_embedding(embedding_client, query)
    vector_query = VectorizedQuery(vector=embed_query, k_nearest_neighbors=50, fields="vector")

    if department:
        filter_param = f"Department eq '{department}'"
        results = search_client.search(vector_queries= [vector_query],
                    vector_filter_mode=VectorFilterMode.PRE_FILTER,
                    filter=filter_param,
                    top=10)
    else:
        results = search_client.search(  
                    vector_queries= [vector_query],
                    top=10
                    )  
    documents = []
    URLS = []  # Use a list to preserve the insertion order
    Names = []  # Use a list to preserve the insertion order

    for result in results:
        documents.append({
            "department": result.get('Department', ''),
            "content": result.get('content', 'No data Found')
        })

        # Only append if the URL or Name is not already in the list to avoid duplicates
        url = result.get('URL')
        name = result.get('Name')

        if url and url not in URLS:
            URLS.append(url)  # Preserve order while avoiding duplicates

        if name and name not in Names:
            Names.append(name)  # Preserve order while avoiding duplicates
    
    # After the loop, you can append the URLs and Names lists to the documents
    documents.append({
        "URLs": URLS,  # Maintain insertion order
        "Names": Names  # Maintain insertion order
    })

    return documents

# Azure Function to handle HTTP request
def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # Get query, category, and department from user request
        query = req.params.get('query')
        department = req.params.get('department', None)

        # Query the documents
        documents = query_documents(query, department)

        prompt = """
                    You are an AI assistant that helps people find information based on the context provided to you.
                    You have no general knowledge so donnot give any general information instead of that give response with "NOTFOUND".
                    Your response should be strictly based on the context provided to you.
                    You should only respond with information directly supported by the 'Context' below.
                    If the 'Context' does not contain sufficient information to answer the query,
                    or if the query is irrelevant or cannot be answered by the context,then strictly
                    respond with "NOTFOUND" and do not generate any answer.
                    And for small talks give response with "NOTFOUND". Small talks means hy ,hello,hii,goodmorning,etc for all this query we get response as "NOTFOUND".

                    Context:
                    ---
                    {content}
                    ---
                    If the User query cannot response by the context or
                    if the context does not contain sufficient information to answer the query,
                    return "NOTFOUND" without providing any additional explanation.s

                """.format(content=documents)

        message_text = [
            {'role': 'system', 'content': prompt}, 
            {'role': 'user', 'content': str(query)}  # Use query directly, as it's the user's question
        ]

        # Get GPT response using the same embedding_client
        gpt_response = embedding_client.chat.completions.create(
            model="gpt-35-turbo-16k",
            messages=message_text,
            temperature=0.3
        )

        # Correctly access the response text
        assistant_response = gpt_response.choices[0].message.content if gpt_response.choices else None
        assistant_response = assistant_response.replace('\n', '<br>')  # Replace \n with a space

        response = {
            "response": assistant_response.strip(),
            "error": None,
            "URLs": documents[-1]['URLs'],  # Access the last document which contains URLs
            "Names": documents[-1]['Names']  # Access the last document which contains Names
        }

        return HttpResponse(
            json.dumps(response), 
            status_code=200, 
            mimetype="application/json",
            headers={
                "Access-Control-Allow-Origin": "*",  # Allow any origin (you can specify your frontend URL here)
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )
    
    except Exception as e:
        logging.error(f"Error: {str(e)}")
        return func.HttpResponse(
            "An error occurred while querying the search index.",
            status_code=500
        )
