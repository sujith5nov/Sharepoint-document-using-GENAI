
document.getElementById("search-btn").addEventListener("click", async function() {
    document.getElementById("results").style.display = "none";
    document.getElementById("greeting-message").innerHTML = "<p>Searching... please wait.</p>";
    const query = document.getElementById("query").value;
    const department = document.getElementById("department").value;

    if (!query) {
        alert("Please enter a search query.");
        return;
    }
    // Show loader before the API call
    document.getElementById("loader").style.display = "block";

    try {
        // Make API request to your Azure Function
        const response = await fetch(`http://localhost:7071/api/HttpTrigger1?query=${query}&department=${department}`);

        if (response.ok) {
            // Parse JSON response
            const data = await response.json();
            console.log(data);  // Log the actual response body
            // Hide loader after receiving response
            document.getElementById("loader").style.display = "none";
            document.getElementById("results").style.display = "block";
            // Check if response contains data
            if (data.response) {
                displayResults(data.response, data.URLs, data.Names);  // Display the assistant response
            }else {
                document.getElementById("results").innerHTML = "<p>No relevant results found.</p>";
                document.getElementById("greeting-message").innerHTML = "<p>Sorry! somthing went worng</p>";
            }
        } else {
            // Handle error if response is not OK
            const errorData = await response.json();
            alert(errorData.error || "An error occurred while fetching results.");
            document.getElementById("loader").style.display = "none";
        }
    } catch (error) {
        // Handle network or other errors
        document.getElementById("greeting-message").innerHTML = "<p>Sorry! somthing went worng</p>";
        document.getElementById("loader").style.display = "none";
    }
});

function displayResults(result, documentUrls, documentNames) {
    const resultsContainer = document.getElementById("results");
    resultsContainer.innerHTML = ""; // Clear previous results

    if (result=="NOTFOUND" ||!result) {
        document.getElementById("greeting-message").innerHTML = "<p>Sorry! No Data Found</p>";
        resultsContainer.innerHTML = "<p>No relevant results found.</p>";
        return ; // Exit function if no results
    } 

    else {
        // Create a div to show the result
        const resultItem = document.createElement("div");
        document.getElementById("greeting-message").innerHTML = "<p>Thankyou </p>";
        resultItem.classList = "result-item";
        if (document.body.classList.contains("light-mode")) {
            resultItem.classList.add("light-mode");
        }
        else{
            resultItem.classList.remove("light-mode")
        }
        resultItem.innerHTML = `
            <h3>Answer:</h3>
            <p>${result}</p>
        `;
        resultsContainer.appendChild(resultItem);

        // Check if reference documents exist
        if (documentUrls && documentUrls.length > 0) {
            // Create expandable reference document section
            const refDocContainer = document.createElement("div");
            refDocContainer.className = "reference-doc-container";

            // Create clickable link for each document
            documentUrls.forEach((url, index) => {
                const documentLink = document.createElement("a");
                documentLink.href = url;
                documentLink.textContent = `${documentNames[index]}`;
                documentLink.target = "_blank"; // Opens the document in a new tab
                documentLink.className = "document-link"; // Optional class for styling

                // Append to reference document container
                refDocContainer.appendChild(documentLink);
            });

            // Create a section that can expand/collapse
            const expandSection = document.createElement("div");
            expandSection.className = "expandable-section";
            expandSection.innerHTML = `
                <p class="reference-text"><a>Reference Documents</a></p>
                <div class="expandable-content" style="display:none;">
                    ${documentUrls.map((url, index) => {
                        return `
                            <p><a href="${url}" target="_blank">${documentNames[index]}</a></p>
                        `;
                    }).join('')}
                </div>
            `;
            // Append the expandable section to the results
            resultItem.appendChild(expandSection);

            // Add event listener to toggle content visibility
            expandSection.querySelector('.reference-text').addEventListener('click', function() {
                const content = expandSection.querySelector('.expandable-content');
                const referenceText = expandSection.querySelector('.reference-text a');
                if (content.style.display === "none") {
                    content.style.display = "block";
                    referenceText.textContent = "Hide Reference Documents";
                } else {
                    content.style.display = "none";
                    referenceText.textContent = "Reference Documents";
                }
            });
        }
    }
}
document.getElementById("theme-toggle-btn").addEventListener("click", function() {
    
    // Toggle the theme
    document.body.classList.toggle("light-mode");
    document.querySelector(".search-container").classList.toggle("light-mode");
    document.querySelector(".navbar").classList.toggle("light-mode");
    document.querySelector(".search-bar").classList.toggle("light-mode");
    document.querySelector("#query").classList.toggle("light-mode");
    document.querySelector("#department").classList.toggle("light-mode");
    document.querySelector("#search-btn").classList.toggle("light-mode");
    document.querySelector("#results").classList.toggle("light-mode");
    document.querySelector(".result-item").classList.toggle("light-mode");
    document.querySelector(".avatar-container").classList.toggle("light-mode");

    // Change the icon of the button depending on the mode
    if (document.body.classList.contains("light-mode")) {
        document.getElementById("theme-toggle-btn").textContent = "🌙";  // Light mode icon
    } else {
        document.getElementById("theme-toggle-btn").textContent = "🌞";  // Dark mode icon
    }
});
